# Wallet Manager
by Fengwei Ban, Zeyu Cheng, and Katie Nguyen
## Procedure
To start this program, "setup_db.sql" must be run to set up the database.

The user must set the username "DB_USERNAME" and the password "DB_PASSWORD" for their SQL server in the JDBC class.

The homepage when the app starts is the Registration page.
If/Once the user is registered, they can log in to view the User Page