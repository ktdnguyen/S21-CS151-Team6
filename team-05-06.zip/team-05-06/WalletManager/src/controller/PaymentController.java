/* This class controls the Homepage, which displays all the transactions of the user after they log in
 *  the data is retrieved from the database via the SQLite database
 */
package controller;

import java.sql.*;

import db.SQLiteConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import model.PaymentModel;

public class PaymentController {
	
	@FXML
	private TableView<PaymentModel> paymenttable;
	
	@FXML
	private TableColumn<PaymentModel, String> pid;
	
	@FXML
	private TableColumn<PaymentModel, String> uid;
	
	@FXML
	private TableColumn<PaymentModel, String> date;
	
	@FXML
	private TableColumn<PaymentModel, String> category;
	
	@FXML
	private TableColumn<PaymentModel, Integer> price;
	
	@FXML
	private TableColumn<PaymentModel, String> notes;
	
	private ObservableList<PaymentModel> data;
	
	public void LoadPaymentData(ActionEvent event) {
		try {
			Connection con = SQLiteConnection.connector();
			this.data = FXCollections.observableArrayList();
			
			// the statement will retrieve the transaction details from the database using the userid related to the user login information
			ResultSet res = con.createStatement().executeQuery("SELECT * FROM Paymentlist");
			while(res.next()) {
				this.data.add(new PaymentModel(res.getString(1), res.getString(2), res.getString(3), res.getString(4), res.getInt(5), res.getString(6)));
			}
			
		}  catch(SQLException e){
			System.out.println(e);
		}
		
		this.pid.setCellValueFactory(new PropertyValueFactory<PaymentModel, String>("pid"));
		this.uid.setCellValueFactory(new PropertyValueFactory<PaymentModel, String>("uid"));
		this.date.setCellValueFactory(new PropertyValueFactory<PaymentModel, String>("date"));
		this.category.setCellValueFactory(new PropertyValueFactory<PaymentModel, String>("category"));
		this.price.setCellValueFactory(new PropertyValueFactory<PaymentModel, Integer>("price"));
		this.notes.setCellValueFactory(new PropertyValueFactory<PaymentModel, String>("notes"));
		
		this.paymenttable.setItems(this.data);
	}
	

}
