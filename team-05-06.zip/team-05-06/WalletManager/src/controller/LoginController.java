/*This class controls the Login page
 */
package controller;

import java.io.IOException;
import java.sql.SQLException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.LoginModel;

public class LoginController{
	
	public LoginModel model = new LoginModel();
	@FXML
	private Label msg;
	
	@FXML
	private TextField username;
	
	@FXML
	private TextField password;
	
	public void Login(ActionEvent event) throws IOException {
		try {
			if(model.Login(username.getText(), password.getText())) {
				
				msg.setText("Login Successful");
				
				Stage st = (Stage)this.password.getScene().getWindow();
				st.close();
				
				Stage primaryStage = new Stage();
				
				Parent root = FXMLLoader.load(getClass().getClassLoader().getResource("view/homePage.fxml"));
				Scene scene= new Scene(root);
				scene.getStylesheets().add(getClass().getClassLoader().getResource("application/application.css").toExternalForm());
				primaryStage.setScene(scene);
				primaryStage.show();
			}
			else {
				//Error when user submits empty login credentials or invalid login credential
				msg.setText("Invalid user name or password");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
}
