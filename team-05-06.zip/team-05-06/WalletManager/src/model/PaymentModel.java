package model;

import javafx.beans.property.StringProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.SimpleIntegerProperty;

public class PaymentModel {
	
	private StringProperty pid;
	private StringProperty uid;
	private StringProperty date;
	private StringProperty category;
	private IntegerProperty price;
	private StringProperty notes;
	
	public PaymentModel(String pid, String uid, String date, String category, int price, String notes) {
		this.pid = new SimpleStringProperty(pid);
		this.date = new SimpleStringProperty(date);
		this.category = new SimpleStringProperty(category);
		this.price = new SimpleIntegerProperty(price);
		this.notes = new SimpleStringProperty(notes);
		
	}

	public StringProperty getPid() {
		return pid;
	}

	public void setPid(StringProperty pid) {
		this.pid = pid;
	}
	
	public StringProperty getUid() {
		return uid;
	}

	public void setUid(StringProperty uid) {
		this.uid = uid;
	}

	public StringProperty getDate() {
		return date;
	}

	public void setDate(StringProperty date) {
		this.date = date;
	}

	public StringProperty getCategory() {
		return category;
	}

	public void setCategory(StringProperty category) {
		this.category = category;
	}

	public IntegerProperty getPrice() {
		return price;
	}

	public void setPrice(IntegerProperty price) {
		this.price = price;
	}

	public StringProperty getNotes() {
		return notes;
	}

	public void setNotes(StringProperty notes) {
		this.notes = notes;
	}
	
	
}
