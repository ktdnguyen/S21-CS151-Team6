package model;

import javafx.beans.property.StringProperty;
import javafx.beans.property.SimpleIntegerProperty;

public class UserModel {

}
