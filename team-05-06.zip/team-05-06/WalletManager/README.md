#Wallet Manager


For this first version of our program, we have a functional Login feature and the base of the homepage.
We used SQLite for the database management.


##Procedure
To run this program, the system should have a JAVA 1.8 environment.
The JDBC connector to connect the JAVA program to the database is in the src folder and has already been added to the build path of the application.


To log in to the system, the user can log in with the username “123” and password “123”. 


Once the user submits the login information, the homepage opens. Right now, for this initial version, the homepage lists the transaction ID, user id (UID), Date, Category, Price, and Total.